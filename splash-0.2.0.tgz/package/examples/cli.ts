#!/usr/bin/env tsx

/**
 * Splash CLI — OpenClaw-style entrypoint.
 *
 * Usage:
 *   splash                          Open an interactive chat.
 *   splash "do X"                   Run a one-shot task from any directory.
 *   splash "do X" --background      Detach; returns a run id.
 *   splash init                     30-second setup wizard (writes ~/.splash/config.json).
 *   splash tui                      Live run dashboard.
 *   splash runs list|logs|stop|retry|attach
 *   splash config list|doctor|preset|set|set-key
 *   splash telegram|slack|whatsapp|messenger|discord  Start a platform bot.
 *   splash help                     Show this help.
 */

import * as p from "@clack/prompts";
import pc from "picocolors";
import { AlpClaw, RunManager, runWorker } from "@alpclaw/core";
import type { AgentPhase, Task } from "@alpclaw/utils";
import { renderBanner, ripple, startLoader } from "@alpclaw/utils";
import {
  readGlobalConfig,
  writeGlobalConfig,
  setApiKey,
  setBotCredential,
  setGlobalValue,
  applyPreset,
  globalConfigPath,
  globalConfigDir,
  runsDir,
  type GlobalConfigShape,
} from "@alpclaw/config";
import { spawnSync } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import * as process from "node:process";
import { marked } from "marked";
import { markedTerminal } from "marked-terminal";

marked.use(markedTerminal() as any);

const PHASE_LABELS: Record<AgentPhase, string> = {
  intake: "Receiving task",
  understand: "Understanding intent",
  plan: "Architecting plan",
  context_fetch: "Accessing memory",
  tool_select: "Selecting capabilities",
  execute: "Executing",
  verify: "Verifying results",
  correct: "Self-correcting",
  finalize: "Finalizing",
  persist: "Writing to persistent memory",
};

const BOT_SPECS: Record<
  string,
  { file: string; label: string; requiredKeys: string[] }
> = {
  telegram:  { file: "telegram.ts",  label: "Telegram",  requiredKeys: ["TELEGRAM_BOT_TOKEN"] },
  slack:     { file: "slack.ts",     label: "Slack",     requiredKeys: ["SLACK_BOT_TOKEN", "SLACK_SIGNING_SECRET"] },
  whatsapp:  { file: "whatsapp.ts",  label: "WhatsApp",  requiredKeys: ["TWILIO_AUTH_TOKEN"] },
  messenger: { file: "messenger.ts", label: "Messenger", requiredKeys: ["MESSENGER_PAGE_TOKEN", "MESSENGER_VERIFY_TOKEN"] },
  discord:   { file: "discord.ts",   label: "Discord",   requiredKeys: ["DISCORD_PUBLIC_KEY", "DISCORD_BOT_TOKEN"] },
};

// ──────────────────────────────────────────────────────────────────────────
// Entry routing
// ──────────────────────────────────────────────────────────────────────────

async function main() {
  const args = process.argv.slice(2);
  const cmd = args[0];

  if (!cmd) {
    await openChat();
    return;
  }

  switch (cmd) {
    case "help":
    case "--help":
    case "-h":
      printHelp();
      return;
    case "init":
    case "setup":
      await runInit();
      return;
    case "config":
      await runConfig(args.slice(1));
      return;
    case "chat":
      await openChat();
      return;
    case "telegram":
    case "slack":
    case "whatsapp":
    case "messenger":
    case "discord":
      await runBot(cmd);
      return;
    case "runs":
      await runRunsCmd(args.slice(1));
      return;
    case "tui":
    case "dashboard":
      await launchTui();
      return;
    case "_worker":
      // internal: spawned by background runs to execute a pre-allocated run id
      if (args[1] && args[2]) {
        await runWorker(args[1], args.slice(2).join(" "));
        return;
      }
      console.error("Usage: splash _worker <run-id> <task>");
      process.exit(2);
      break;
    case "run":
      if (args[1] && BOT_SPECS[args[1]]) {
        await runBot(args[1]);
        return;
      }
      // `splash run "task" [--background]` form
      if (args[1]) {
        const rest = args.slice(1);
        const bg = rest.includes("--background") || rest.includes("-b");
        const prompt = rest.filter((a) => a !== "--background" && a !== "-b").join(" ");
        await runFromCli(prompt, { background: bg });
        return;
      }
      break;
  }

  // Fallback: treat args as a one-shot prompt. Support --background flag.
  const bg = args.includes("--background") || args.includes("-b");
  const promptText = args.filter((a) => a !== "--background" && a !== "-b").join(" ");
  await runFromCli(promptText, { background: bg });
}

// ──────────────────────────────────────────────────────────────────────────
// Help
// ──────────────────────────────────────────────────────────────────────────

function printHelp() {
  console.log(renderBanner({ subtitle: "Autonomous Agent" }));
  console.log(
    [
      pc.bold("USAGE"),
      `  ${pc.cyan("splash")}                            Open an interactive chat`,
      `  ${pc.cyan("splash")} "build me a script"        Run a one-shot task`,
      `  ${pc.cyan("splash")} "..." --background          Detach and return a run id`,
      "",
      pc.bold("CORE COMMANDS"),
      `  ${pc.cyan("splash init")}                       30-second setup wizard`,
      `  ${pc.cyan("splash tui")}                        Open the live run dashboard`,
      `  ${pc.cyan("splash help")}                       Show this help`,
      "",
      pc.bold("RUNS"),
      `  ${pc.cyan("splash runs list")}                  Show active/recent runs`,
      `  ${pc.cyan("splash runs logs")} ID [--follow]    Tail events for a run`,
      `  ${pc.cyan("splash runs attach")} ID             Open a run in the TUI`,
      `  ${pc.cyan("splash runs stop")} ID               Cancel a running run`,
      `  ${pc.cyan("splash runs retry")} ID [-b]         Re-run a task`,
      "",
      pc.bold("CONFIG"),
      `  ${pc.cyan("splash config list")}                Show effective config`,
      `  ${pc.cyan("splash config doctor")}              Verify keys / perms / reachability`,
      `  ${pc.cyan("splash config preset")} fast|balanced|safe`,
      `  ${pc.cyan("splash config set")} KEY VAL         Set a field`,
      `  ${pc.cyan("splash config set-key")} P VAL       Save API key for provider`,
      "",
      pc.bold("PLATFORMS"),
      `  ${pc.cyan("splash telegram")}|${pc.cyan("slack")}|${pc.cyan("whatsapp")}|${pc.cyan("messenger")}|${pc.cyan("discord")}`,
      "",
      pc.dim(`Config: ${globalConfigPath()}`),
      pc.dim(`Env:    SPLASH_* and legacy ALPCLAW_* vars both work. .env in cwd is read.`),
      pc.dim(`Alias:  \`alpclaw\` still works — it delegates to \`splash\`.`),
      "",
    ].join("\n"),
  );
}

// ──────────────────────────────────────────────────────────────────────────
// init / config
// ──────────────────────────────────────────────────────────────────────────

async function runInit() {
  console.log(renderBanner({ subtitle: "Setup" }));
  p.intro(pc.bgCyan(pc.black(" 💧 SPLASH INIT ")));
  p.log.message("Pick a provider and drop in a key. You can change this any time with `splash config`.");

  const existing = readGlobalConfig();
  const next: GlobalConfigShape = { ...existing };
  next.apiKeys = { ...(existing.apiKeys || {}) };

  const provider = await p.select({
    message: "Default provider:",
    options: [
      { value: "openrouter", label: "OpenRouter — recommended, unlocks Kimi K2, DeepSeek, Qwen, Claude, GPT-4" },
      { value: "claude",     label: "Anthropic Claude" },
      { value: "openai",     label: "OpenAI (GPT-4o)" },
      { value: "gemini",     label: "Google Gemini" },
      { value: "deepseek",   label: "DeepSeek" },
      { value: "ollama",     label: "Ollama (local, no key needed)" },
    ],
  });
  if (p.isCancel(provider)) return abort();

  next.defaultProvider = provider as string;

  if (provider !== "ollama") {
    const key = await p.password({ message: `Paste your ${provider} API key (input hidden):` });
    if (p.isCancel(key)) return abort();
    if (key) next.apiKeys[provider as string] = key as string;
  }

  if (provider === "openrouter") {
    const model = await p.select({
      message: "Default model:",
      options: [
        { value: "moonshotai/kimi-k2",           label: "Kimi K2 (Moonshot) — long context, strong coding" },
        { value: "moonshotai/kimi-k2-0905",      label: "Kimi K2 0905 (newer snapshot)" },
        { value: "anthropic/claude-3.5-sonnet",  label: "Claude 3.5 Sonnet" },
        { value: "deepseek/deepseek-chat",       label: "DeepSeek V3" },
        { value: "qwen/qwen-2.5-coder-32b-instruct", label: "Qwen 2.5 Coder 32B" },
        { value: "openai/gpt-4o",                label: "GPT-4o" },
      ],
    });
    if (!p.isCancel(model)) next.defaultModel = model as string;
  }

  const safety = await p.select({
    message: "Safety level:",
    options: [
      { value: "standard",   label: "Standard — confirms risky actions (recommended)" },
      { value: "strict",     label: "Strict — confirms every action" },
      { value: "permissive", label: "Permissive — fully autonomous" },
    ],
  });
  if (!p.isCancel(safety)) next.safetyMode = safety as GlobalConfigShape["safetyMode"];

  writeGlobalConfig(next);
  p.outro(pc.green(`✓ Saved to ${globalConfigPath()}`));
  console.log(pc.dim(`\nTry it: ${pc.cyan("splash \"summarize this folder\"")}`));
}

async function runConfig(args: string[]) {
  const sub = args[0];
  if (!sub || sub === "list" || sub === "show") {
    const cfg = readGlobalConfig();
    const redacted = {
      ...cfg,
      apiKeys: Object.fromEntries(
        Object.entries(cfg.apiKeys || {}).map(([k, v]) => [k, redact(v)]),
      ),
      bots: Object.fromEntries(
        Object.entries(cfg.bots || {}).map(([bot, fields]) => [
          bot,
          Object.fromEntries(Object.entries(fields).map(([k, v]) => [k, redact(v)])),
        ]),
      ),
    };
    console.log(pc.dim(`# ${globalConfigPath()}`));
    console.log(JSON.stringify(redacted, null, 2));
    return;
  }

  if (sub === "path") {
    console.log(globalConfigPath());
    return;
  }

  if (sub === "set") {
    const [key, ...rest] = args.slice(1);
    const val = rest.join(" ");
    if (!key || val === "") {
      console.error("Usage: splash config set <defaultProvider|defaultModel|safetyMode> <value>");
      process.exit(2);
    }
    const allowed = ["defaultProvider", "defaultModel", "safetyMode"] as const;
    if (!(allowed as readonly string[]).includes(key)) {
      console.error(`Unknown key. Allowed: ${allowed.join(", ")}`);
      process.exit(2);
    }
    setGlobalValue(key as (typeof allowed)[number], val as any);
    console.log(pc.green(`✓ ${key} = ${val}`));
    return;
  }

  if (sub === "set-key") {
    const [provider, ...rest] = args.slice(1);
    const val = rest.join(" ");
    if (!provider || !val) {
      console.error("Usage: splash config set-key <provider> <api-key>");
      process.exit(2);
    }
    setApiKey(provider, val);
    console.log(pc.green(`✓ API key saved for ${provider}`));
    return;
  }

  if (sub === "set-bot") {
    const [bot, field, ...rest] = args.slice(1);
    const val = rest.join(" ");
    if (!bot || !field || !val) {
      console.error("Usage: splash config set-bot <bot> <field> <value>");
      process.exit(2);
    }
    setBotCredential(bot, field, val);
    console.log(pc.green(`✓ ${bot}.${field} saved`));
    return;
  }

  if (sub === "doctor") {
    await runDoctor(args.slice(1));
    return;
  }

  if (sub === "preset") {
    const name = args[1];
    if (!name || !["fast", "balanced", "safe"].includes(name)) {
      console.error("Usage: splash config preset <fast|balanced|safe>");
      process.exit(2);
    }
    const cfg = applyPreset(name as "fast" | "balanced" | "safe");
    console.log(pc.green(`✓ preset applied: ${name}`));
    console.log(pc.dim(`  safetyMode=${cfg.safetyMode}  runtime=${cfg.runtime}`));
    return;
  }

  console.error("Unknown config subcommand. Use: list | path | set | set-key | set-bot | doctor | preset");
  process.exit(2);
}

// ──────────────────────────────────────────────────────────────────────────
// config doctor
// ──────────────────────────────────────────────────────────────────────────

async function runDoctor(args: string[]): Promise<void> {
  const json = args.includes("--json");
  const cfg = readGlobalConfig();
  const checks: { name: string; ok: boolean; detail: string; fix?: string }[] = [];

  // 1. provider key present
  const hasAnyKey =
    Object.values(cfg.apiKeys || {}).some(Boolean) ||
    !!process.env.ANTHROPIC_API_KEY ||
    !!process.env.OPENAI_API_KEY ||
    !!process.env.OPENROUTER_API_KEY ||
    !!process.env.GOOGLE_API_KEY ||
    !!process.env.DEEPSEEK_API_KEY ||
    !!process.env.OLLAMA_BASE_URL;
  checks.push({
    name: "provider key",
    ok: hasAnyKey,
    detail: hasAnyKey ? "found" : "none",
    fix: "splash init  — or  splash config set-key openrouter sk-or-...",
  });

  // 2. write perms
  const dir = globalConfigDir();
  let writable = false;
  try {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    fs.accessSync(dir, fs.constants.W_OK);
    writable = true;
  } catch {
    writable = false;
  }
  checks.push({
    name: "config dir writable",
    ok: writable,
    detail: dir,
    fix: `chmod u+w ${dir}`,
  });

  // 3. runs dir
  const rdir = runsDir();
  let runsOK = false;
  try {
    fs.mkdirSync(rdir, { recursive: true, mode: 0o700 });
    fs.accessSync(rdir, fs.constants.W_OK);
    runsOK = true;
  } catch {
    runsOK = false;
  }
  checks.push({ name: "runs dir writable", ok: runsOK, detail: rdir });

  // 4. provider reachability (best effort — skip if no fetch)
  const defaultProvider = cfg.defaultProvider || "openrouter";
  const providerHost: Record<string, string> = {
    openrouter: "https://openrouter.ai",
    claude: "https://api.anthropic.com",
    openai: "https://api.openai.com",
    gemini: "https://generativelanguage.googleapis.com",
    deepseek: "https://api.deepseek.com",
    ollama: process.env.OLLAMA_BASE_URL || "http://localhost:11434",
  };
  const host = providerHost[defaultProvider];
  let reachable = false;
  if (host && typeof fetch === "function") {
    try {
      const ac = new AbortController();
      const timer = setTimeout(() => ac.abort(), 3000);
      const res = await fetch(host, { method: "HEAD", signal: ac.signal }).catch(() => null);
      clearTimeout(timer);
      reachable = !!res;
    } catch {
      reachable = false;
    }
  }
  checks.push({
    name: `provider reachable (${defaultProvider})`,
    ok: reachable,
    detail: host || "?",
    fix: "check network / VPN",
  });

  if (json) {
    console.log(JSON.stringify({ checks }, null, 2));
    return;
  }

  console.log(pc.cyan(pc.bold("💧 splash config doctor")));
  console.log();
  for (const c of checks) {
    const icon = c.ok ? pc.green("✓") : pc.red("✗");
    console.log(`  ${icon} ${pc.bold(c.name)}  ${pc.dim(c.detail)}`);
    if (!c.ok && c.fix) console.log(`      ${pc.yellow("fix:")} ${c.fix}`);
  }
  const bad = checks.filter((c) => !c.ok).length;
  console.log();
  console.log(bad === 0 ? pc.green("All checks passed.") : pc.yellow(`${bad} check(s) failed.`));
  if (bad !== 0) process.exit(1);
}

// ──────────────────────────────────────────────────────────────────────────
// runs subcommands
// ──────────────────────────────────────────────────────────────────────────

async function runRunsCmd(args: string[]): Promise<void> {
  const sub = args[0] || "list";
  const json = args.includes("--json");
  const rm = new RunManager();

  if (sub === "list") {
    const list = rm.list();
    if (json) {
      console.log(JSON.stringify(list, null, 2));
      return;
    }
    if (list.length === 0) {
      console.log(pc.dim("no runs yet. Start one with `splash \"do X\" --background`"));
      return;
    }
    console.log(pc.cyan(pc.bold("💧 runs")));
    for (const r of list.slice(0, 30)) {
      const color = statusColor(r.status);
      console.log(
        `  ${color(badgeForStatus(r.status))} ${pc.dim(r.id.slice(-10))}  ${r.task.slice(0, 60)}` +
          pc.dim(`  (${r.mode})`),
      );
    }
    return;
  }

  const id = args[1];

  if (sub === "show" || sub === "get") {
    if (!id) return failUsage("splash runs show <id>");
    const rec = rm.get(id);
    if (!rec) { console.error("not found"); process.exit(1); }
    console.log(JSON.stringify(rec, null, 2));
    return;
  }

  if (sub === "stop" || sub === "cancel") {
    if (!id) return failUsage("splash runs stop <id>");
    const ok = rm.stop(id);
    console.log(ok ? pc.green(`✓ stopped ${id}`) : pc.yellow("already ended or unknown"));
    return;
  }

  if (sub === "retry") {
    if (!id) return failUsage("splash runs retry <id>");
    const bg = args.includes("--background") || args.includes("-b");
    const { id: newId } = await rm.retry(id, { background: bg });
    console.log(pc.green(`✓ retry queued as ${newId}`));
    return;
  }

  if (sub === "logs") {
    if (!id) return failUsage("splash runs logs <id>");
    const follow = args.includes("--follow") || args.includes("-f");
    const events = rm.events(id);
    for (const e of events) console.log(formatEventLine(e, json));
    if (follow) {
      const stop = rm.follow(id, (e) => console.log(formatEventLine(e, json)));
      process.on("SIGINT", () => { stop(); process.exit(0); });
    }
    return;
  }

  if (sub === "attach") {
    if (!id) return failUsage("splash runs attach <id>");
    await launchTui(id);
    return;
  }

  failUsage("splash runs <list|show|stop|retry|logs|attach> [id] [--json|--follow]");
}

function failUsage(msg: string): void {
  console.error(msg);
  process.exit(2);
}

function statusColor(s: string): (t: string) => string {
  switch (s) {
    case "running":   return pc.cyan;
    case "succeeded": return pc.green;
    case "failed":    return pc.red;
    case "cancelled": return pc.gray;
    case "queued":    return pc.yellow;
    default:          return pc.white;
  }
}

function badgeForStatus(s: string): string {
  switch (s) {
    case "running":   return "◌ running  ";
    case "succeeded": return "✓ succeeded";
    case "failed":    return "✗ failed   ";
    case "cancelled": return "⊘ cancelled";
    case "queued":    return "○ queued   ";
    default:          return "· " + s;
  }
}

function formatEventLine(e: any, json: boolean): string {
  if (json) return JSON.stringify(e);
  const t = new Date(e.at).toISOString().slice(11, 19);
  switch (e.type) {
    case "RunCreated":   return pc.gray(`[${t}]`) + ` created ${pc.dim("(" + e.mode + ")")}`;
    case "RunStarted":   return pc.gray(`[${t}]`) + pc.cyan(" started");
    case "PhaseChanged": return pc.gray(`[${t}]`) + pc.cyan(` phase → ${e.phase}`);
    case "ToolCalled":   return pc.gray(`[${t}]`) + pc.magenta(` ⚡ ${e.tool}`);
    case "LogLine":      return pc.gray(`[${t}]`) + ` ${e.text}`;
    case "RunCompleted": return pc.gray(`[${t}]`) + pc.green(` ✓ completed (${e.steps ?? 0} steps)`);
    case "RunFailed":    return pc.gray(`[${t}]`) + pc.red(` ✗ ${e.error}`);
    case "RunCancelled": return pc.gray(`[${t}]`) + pc.yellow(` ⊘ cancelled`);
    default:             return pc.gray(`[${t}]`) + " " + JSON.stringify(e);
  }
}

// ──────────────────────────────────────────────────────────────────────────
// TUI launcher
// ──────────────────────────────────────────────────────────────────────────

async function launchTui(_focusId?: string): Promise<void> {
  if (!process.stdout.isTTY) {
    console.log(pc.dim("TUI requires an interactive terminal. Falling back to run list."));
    await runRunsCmd(["list"]);
    return;
  }
  const ink = await import("ink");
  const React = await import("react");
  const { TuiApp } = await import("@alpclaw/core");
  const manager = new RunManager();
  const { waitUntilExit } = ink.render(
    React.createElement(TuiApp, { manager }),
    { exitOnCtrlC: true },
  );
  await waitUntilExit();
}

// ──────────────────────────────────────────────────────────────────────────
// runFromCli — foreground or background one-shot
// ──────────────────────────────────────────────────────────────────────────

async function runFromCli(prompt: string, opts: { background: boolean }): Promise<void> {
  if (!prompt.trim()) {
    await openChat();
    return;
  }
  ensureConfigured();
  if (opts.background) {
    const rm = new RunManager();
    const { id } = await rm.start(prompt, { background: true });
    console.log(pc.green(`✓ started background run ${pc.bold(id)}`));
    console.log(pc.dim(`  follow: splash runs logs ${id} --follow`));
    console.log(pc.dim(`  attach: splash runs attach ${id}`));
    return;
  }
  await runOneShot(prompt);
}

// ──────────────────────────────────────────────────────────────────────────
// Bots
// ──────────────────────────────────────────────────────────────────────────

async function runBot(name: string) {
  const spec = BOT_SPECS[name];
  if (!spec) {
    console.error(`Unknown platform: ${name}`);
    process.exit(2);
  }

  // Hydrate env from global config (bots.<name>.*) so bot files can stay env-var-based.
  const cfg = readGlobalConfig();
  const botCreds = cfg.bots?.[name] || {};
  const env = { ...process.env };
  for (const k of spec.requiredKeys) {
    if (!env[k] && botCreds[k]) env[k] = botCreds[k];
  }
  // Also hydrate provider keys for the agent itself.
  for (const [prov, key] of Object.entries(cfg.apiKeys || {})) {
    const envKey = providerEnvKey(prov);
    if (envKey && !env[envKey]) env[envKey] = key;
  }

  // Check required keys.
  const missing = spec.requiredKeys.filter((k) => !env[k]);
  if (missing.length) {
    console.error(pc.red(`Missing ${spec.label} credentials: ${missing.join(", ")}`));
    console.error(pc.dim("Run `splash config set-bot " + name + " <FIELD> <value>` for each."));
    process.exit(2);
  }

  const alpclawHome = process.env.SPLASH_HOME || process.env.ALPCLAW_HOME || process.cwd();
  const botPath = path.resolve(alpclawHome, "bots", spec.file);
  if (!fs.existsSync(botPath)) {
    console.error(pc.red(`Bot entrypoint not found at ${botPath}`));
    process.exit(1);
  }

  console.log(renderBanner({ subtitle: `${spec.label} bridge` }));
  console.log(pc.dim(`Starting ${name}...`));

  const tsxName = process.platform === "win32" ? "tsx.cmd" : "tsx";
  const tsxCandidates = [
    path.resolve(alpclawHome, "node_modules", ".bin", tsxName),
    path.resolve(alpclawHome, "..", "..", "node_modules", ".bin", tsxName),
    tsxName,
  ];
  const tsxBin = tsxCandidates.find((p) => fs.existsSync(p)) || tsxName;

  const result = spawnSync(tsxBin, [botPath], { stdio: "inherit", env });
  process.exit(result.status ?? 0);
}

function providerEnvKey(provider: string): string | null {
  switch (provider) {
    case "claude":     return "ANTHROPIC_API_KEY";
    case "openai":     return "OPENAI_API_KEY";
    case "gemini":     return "GOOGLE_API_KEY";
    case "deepseek":   return "DEEPSEEK_API_KEY";
    case "openrouter": return "OPENROUTER_API_KEY";
    default:           return null;
  }
}

// ──────────────────────────────────────────────────────────────────────────
// One-shot + chat
// ──────────────────────────────────────────────────────────────────────────

function loadPersona(): string | undefined {
  const localChar = path.resolve(process.cwd(), "character.md");
  const home = process.env.HOME || process.env.USERPROFILE || "";
  const splashChar = path.resolve(home, ".splash", "character.md");
  const globalChar = path.resolve(home, ".alpclaw", "character.md");
  if (fs.existsSync(localChar)) return fs.readFileSync(localChar, "utf-8");
  if (fs.existsSync(splashChar)) return fs.readFileSync(splashChar, "utf-8");
  if (fs.existsSync(globalChar)) return fs.readFileSync(globalChar, "utf-8");
  return undefined;
}

function ensureConfigured(): void {
  const cfg = readGlobalConfig();
  const hasKey = Object.values(cfg.apiKeys || {}).some(Boolean) ||
    process.env.ANTHROPIC_API_KEY ||
    process.env.OPENAI_API_KEY ||
    process.env.OPENROUTER_API_KEY ||
    process.env.GOOGLE_API_KEY ||
    process.env.DEEPSEEK_API_KEY ||
    process.env.OLLAMA_BASE_URL;

  if (!hasKey) {
    console.log(renderBanner({ subtitle: "First run" }));
    console.log(pc.yellow("No API key configured yet. Run:"));
    console.log(`  ${pc.cyan("splash init")}`);
    console.log(pc.dim("Or, without the wizard:"));
    console.log(`  ${pc.cyan("splash config set-key openrouter sk-or-...")}`);
    process.exit(1);
  }
}

function buildAgent(): AlpClaw {
  ensureConfigured();
  try {
    return AlpClaw.create();
  } catch (err) {
    console.error(pc.red(`Failed to initialize Splash: ${String(err)}`));
    process.exit(1);
  }
}

function printStatusLine(a: AlpClaw): void {
  const p = a.config.providers;
  const s = a.config.safety;
  const runtime = readGlobalConfig().runtime || "foreground";
  console.log(
    "  " +
      pc.cyan("💧 ") +
      pc.bold("splash") +
      pc.dim("  provider=") + pc.white(p.default) +
      pc.dim("  model=") + pc.white(p.defaultModel) +
      pc.dim("  safety=") + pc.white(s.mode) +
      pc.dim("  runtime=") + pc.white(runtime),
  );
}

async function runOneShot(prompt: string) {
  const alpclaw = buildAgent();
  console.log(renderBanner({ subtitle: "Task", compact: true }));
  printStatusLine(alpclaw);
  await runTask(alpclaw, prompt, loadPersona());
}

async function openChat() {
  const alpclaw = buildAgent();
  console.log(renderBanner({ subtitle: "Chat" }));
  printStatusLine(alpclaw);
  p.intro(pc.bgCyan(pc.black(" 💧 SPLASH ")));
  p.log.message(pc.dim("Type your task. `exit` quits. `/help` for commands. `/tui` for dashboard."));

  while (true) {
    const input = await p.text({
      message: pc.cyan("you"),
      placeholder: "e.g., scan this folder for bugs, build a fastapi app",
      validate: (val) => (!val || val.trim().length === 0 ? "Please enter a task." : undefined),
    });

    if (p.isCancel(input)) break;
    const text = String(input).trim();
    if (!text || text === "exit" || text === "quit") break;
    if (text === "/help") { printHelp(); continue; }
    if (text === "/config") { await runConfig(["list"]); continue; }
    if (text === "/tui") { await launchTui(); continue; }
    if (text === "/runs") { await runRunsCmd(["list"]); continue; }

    await runTask(alpclaw, text, loadPersona());
  }

  p.outro(pc.cyan("bye"));
}

async function runTask(alpclaw: AlpClaw, description: string, persona?: string): Promise<void> {
  let s = p.spinner();
  let currentPhase = "";

  const updateSpinner = (message: string) => {
    if (currentPhase && currentPhase !== message) {
      s.stop(pc.green(`✓ ${currentPhase}`));
      s = p.spinner();
    }
    currentPhase = message;
    s.start(pc.blue(message));
  };

  p.log.step(pc.bold(description));

  const agent = alpclaw.createAgent({
    systemPersona: persona,
    onPhaseChange: (phase: AgentPhase, _task: Task) => {
      updateSpinner(PHASE_LABELS[phase] || phase);
    },
    onToolCall: (toolName: string, args: Record<string, unknown>) => {
      s.message(`${pc.magenta("⚡")} ${pc.bold(toolName)} ${pc.dim(JSON.stringify(args).slice(0, 60))}`);
    },
    onStepComplete: () => {},
    onError: (error: string, phase: AgentPhase) => {
      p.log.error(pc.red(`[${phase}] ${error}`));
    },
    onConfirmationRequired: async (action: string, risk: string): Promise<boolean> => {
      s.stop("Safety engine paused execution.");
      const allowed = await p.confirm({
        message: `${pc.bgYellow(pc.black(" WARN "))} ${pc.bold(action)} (risk: ${pc.red(risk)}). Allow?`,
      });
      s = p.spinner();
      s.start("Resuming...");
      return !!allowed && !p.isCancel(allowed);
    },
  });

  const result = await agent.run(description);

  if (currentPhase) s.stop(pc.green(`✓ ${currentPhase}`));

  if (result.ok) {
    const task = result.value;
    const body = task.result?.summary ? marked.parse(task.result.summary) : "No output.";
    p.note(
      [
        `${pc.cyan("status:")} ${task.status === "completed" ? pc.green(task.status) : pc.yellow(task.status)}`,
        `${pc.cyan("steps:")}  ${task.steps.length}`,
        `\n${body}`,
      ].join("\n"),
      "Result",
    );
  } else {
    p.log.error(pc.bgRed(pc.white(" ERROR ")) + " " + result.error.message);
  }
}

// ──────────────────────────────────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────────────────────────────────

function redact(v: string): string {
  if (!v) return "";
  if (v.length <= 8) return "****";
  return v.slice(0, 4) + "…" + v.slice(-4);
}

function abort(): never {
  p.cancel("Setup cancelled.");
  process.exit(0);
}

main().catch((err) => {
  console.error(pc.bgRed(pc.white(" FATAL ")) + `\n\n${err?.stack || err}`);
  process.exit(1);
});
